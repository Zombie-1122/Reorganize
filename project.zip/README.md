# M3U Reorganizer APK
1. Upload everything in this folder to a new GitHub repo (keep the `.github` folder).
2. Open the repo's **Actions** tab, wait for "Build APK" to finish (or run it manually).
3. Open the finished run, download the **M3U-Reorganizer-APK** artifact, unzip it and install the .apk.
