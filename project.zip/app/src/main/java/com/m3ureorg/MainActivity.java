package com.m3ureorg;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.net.*;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private static final int REQ = 1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "Select playlist"), REQ);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        if (r == REQ && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d));
            chooser = null;
        }
    }

    private void toast(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    private class Bridge {
        @JavascriptInterface public void save(String text) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, "playlist-" + System.currentTimeMillis() + ".m3u");
                v.put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(text.getBytes("UTF-8")); }
                toast("Saved to Downloads");
            } catch (Exception e) { toast("Save failed: " + e.getMessage()); }
        }

        @JavascriptInterface public void fetch(final String url) {
            new Thread(() -> {
                try {
                    String cur = url;
                    HttpURLConnection c = null;
                    for (int i = 0; i < 6; i++) {
                        c = (HttpURLConnection) new URL(cur).openConnection();
                        c.setInstanceFollowRedirects(false);
                        c.setRequestProperty("User-Agent", "Mozilla/5.0");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                        int code = c.getResponseCode();
                        if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                            cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                            c.disconnect();
                        } else break;
                    }
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    try (InputStream in = c.getInputStream()) {
                        byte[] buf = new byte[16384]; int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    }
                    final String js = "window.onFetched(" + JSONObject.quote(bo.toString("UTF-8")) + ")";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                } catch (Exception e) {
                    final String js = "window.onFetchErr(" + JSONObject.quote(String.valueOf(e.getMessage())) + ")";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                }
            }).start();
        }
    }
}
